# CS464 - Fitts's Law in Osu - README

## Maxwell Nieberger

### About
This is my term project for CS464: Introduction to Human-Computer Interaction, Spring 2021 at CSU.
It is a study using publicly available osu replay files and a python parsing library to investigate the effect that difficulty according to Fitts's law has on a player's ability to correctly time inputs.

### Links
* Website: https://www.cs.colostate.edu/~mxnieb/#/
* Overview Video: https://youtu.be/Yt6PPkTDsWg
* Presentation Video: 
* GitHub Repository: https://github.com/9burger/cs464-HCI_Fitts-Law-in-Osu
