####  
 
First Last  
Title  
 
[me @ colostate.edu](mailto:me-@-colostate.edu)   
[CSB 000](http://map.concept3d.com/?id=748#!m/122341)  
[+1-970-491-0000](tel:1-970-491-0000)   


####  
  
![me](images/me.png)
 
 
####  
    
[Computer Science Department](http://www.colostate.edu)  
[Colorado State University](http://www.cs.colostate.edu)  
1873 Campus Delivery  
[Fort Collins](http://fcgov.com), CO  
USA 80523-1873


### Bio

Single paragraph written in first person containing bio and research interests.


### Fall 2018 

| What | When |
| :--- | :---: |
| [CS001 Introduction to Computing](#/course) | MWF 12:00-12:50 |
| Office hours in [CSB 000](http://map.concept3d.com/?id=748#!m/122341) | MWF 13:00-13:50 |
| | Or by appointment. |


# Usage

This faculty home page is intended to be a quick summary of the most pertinent information for both students and fellow researchers. 
It answers the key questions:
* Do I have the right person?
* How/when/where can I contact them?
* Where I find additional information about them? 

You can add additional pages (Projects, Publications, ...) with more information by creating additional markdown files and adding them to the list of pages in the [`site.json`](#/site) file.

This page would replace the current home page on this site.
